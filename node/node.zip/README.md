magicnodeball_node
==================

the node side
